<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Apagar Rifa</title>
    <link href="style.css" rel="stylesheet" type="text/css">
    </head>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    
    <style>
        #texto{
            text-align: right;
        }
        #apagar{
            float: right;
        }
        #obrigatorio{
            color: red;
        }
        #form{
            border-radius: 5px;
            background-color: #f2f2f2;
            padding: 20px;
            width: 50%;
            text-align: left;
        }
        input[type=text], input[type=password], input[type=number]{
            width: 85%;
        }
        select{
            width: 35%;
        }
        input[type=submit], input[type=reset] {
            cursor: pointer;
        }
    </style>
    
    <body>
    <center>
        <div id="form">
            
            <form method="POST" action="../Controle/remove_rifa.php">
                
                <fieldset>
                    
                    
                    <label id="obrigatorio">*</label>
                    <label>Insira o nome da rifa que deseja apagar: </label><br>
                    <input type="text" name="nome_rifa" value="" autofocus="" autocomplete="off" required="">
                    <input type="submit" id="apagar" value="Apagar">
                </fieldset>
                                
            </form>
            
        </div>
    </center>
    </body>
</html>
