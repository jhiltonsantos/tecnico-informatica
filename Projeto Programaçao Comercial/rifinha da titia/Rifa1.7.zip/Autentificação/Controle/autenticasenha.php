<?php
	
	include_once 'conectbd.php';
	
    /*
	session_cache_expire(5);
    $cache_expire = session_cache_expire();
    session_start();
    */
	$senha = $_POST["senha"];
	$user = $_POST["user"];
	
	$sql = "SELECT * FROM Usuario WHERE usuario = '$user' AND senha = '$senha';";
    
    $res = mysqli_query($conecta_banco, $sql);
    $escrever = mysqli_fetch_array($res);
    /*
    $palavras = explode(" ", $escrever["user"]);
    $quantidade = count($palavras)-1;
    */
    if(mysqli_num_rows($res) == 1){
       /* session_start();
        //$_SESSION["nomeUsuario"] = $palavras[0]." ".$palavras[$quantidade];
        $_SESSION["usuario"] = $user;
        $_SESSION["senha"] = $senha;
        $_SESSION["autenticando"] = true;
        switch ($escrever["tipo"]){
            case 1:
                header("location: AdmMain.html");
                break;
            case 2:
                echo "<script>window.location='http://localhost/Altereções3/Autentificação/pontos.php';</script>";
                break;
        }*/
        session_start();
        $_SESSION["usuario"] = $user;
        $_SESSION["senha"] = $senha;
        $_SESSION["autenticando"] = true;
        header("Location: ..\Mostrar\cliente.php");
    }
    else{
        //unset($_SESSION["nomeUsuario"]);
        unset($_SESSION["usuario"]);
        unset($_SESSION["senha"]);
        setcookie("erro", "Usuário ou senha incorretos", time()+1, "/");
        header("location: ..\Mostrar\login.php");
    }

?>