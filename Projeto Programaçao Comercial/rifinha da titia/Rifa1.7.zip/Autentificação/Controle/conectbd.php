<?php 



$host="127.0.0.1";
$port=3306;
$socket="";
$user="root";
$password="";
$dbname="rifa";

$conecta_banco = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Não Ocoreu Conexão Com o Banco de Dados' . mysqli_connect_error());

//$con->close();
//
//
//
//
//
?>