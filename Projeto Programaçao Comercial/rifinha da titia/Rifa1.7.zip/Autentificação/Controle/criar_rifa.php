<html>
    <head>
        <meta charset="UTF-8">
        <title>Recebe Formulario Rifa</title>
    <script type="text/javascript" src="jquery-3.3.1.js"></script>
    </head>
    <body>
	
        <?php
            
        if($_SERVER["REQUEST_METHOD"] == "POST"){
            //Conexão BD
            require_once ('conectbd.php');
            
            //Recebendo Formulário
            $nome = $_POST['nome_rifa'];
            $descricao = $_POST['descricao'];
            $premio  = $_POST['premio'];
            $dt_inicio = $_POST['dt_inicio'];
            $dt_prev = $_POST['dt_prev'];
      	    $valor = $_POST['valor']; 
            
            $erro = 0;

            if(isset($_POST['descricao']) == " "){
                $descricao = "NULL";
            }
          }  


          if($erro == 0){
            
            $inserir = "INSERT INTO Rifa ('nome_rifa','descrição','valor',Premio','data_inicio','data_prev_sorteio') VALUES  ('$nome','$descricao','$','$premio','$dt_inicio','$dt_prev')";
                
            $query = mysqli_query($conecta_banco, $inserir);
                
            if($query){
                    $pass = 'Rifa Cadastrada!';
                    echo $pass;
                    //header("location: AdmMain.html");
            }
            else {
                    $pass = 'Erro ao Inserir!';
                    $erro = 1;
                    echo $pass;
                    //header("location: form_rifa.php");
            }
            
            }




        ?>

    </body>
</html>