<?php
    
    require_once ('conectbd.php');

    $nome = filter_input(INPUT_POST, "nome_rifa");
    
    $query = mysqli_query($conecta_banco, "DELETE FROM Rifa WHERE nome_rifa = '$nome'");
    
    if($query){
        $pass = 'Rifa Removida!';
        echo $pass;
       // header("location: ..\Mostrar\sorteio.php");
    }
    else {
        $pass = 'Erro ao remover!';
        echo $pass;
        //header("location: ..\Mostrar\apaga_rifa.php");
    }
