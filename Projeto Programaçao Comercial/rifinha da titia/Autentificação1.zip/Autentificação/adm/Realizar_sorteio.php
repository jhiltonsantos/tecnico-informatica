<html>
    <head>
        <meta charset="UTF-8">
        <link rel="shortcut icon" href="icone.ico" type="image/x-icon" />
        <title>Sorteio</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<style>    
    body {
        margin: 0;
        background-color: white;
    	}
    
    img {
        max-width: 100%;
        height: auto;
    }
    
    
    
</style>

<body>

<?php
 
// Matriz com todos os participantes
$participantes = array("Rafael", "João", "Maria", "Pedro", "Patricia", "Camila", "Roberto");

// Definindo o número de participantes
$numParticipantes = sizeof($participantes);
 
// Informações adicionais
$chances = round((1 / $numParticipantes) * 100);
echo "- Temos no total <b>".$numParticipantes."</b> participantes; <br />";
echo "- Cada participante teve <b>".$chances."%</b> de chance de ganhar; <br /><br />";

// Sorteando
 
$sorteado[1] = $participantes[rand(0,$numParticipantes - 1)];
 
for ($i = 1; $i < 2; $i++) {
	$sorteado[2] = $participantes[rand(0,$numParticipantes - 1)];
	// Caso o ganhador já tenha saido, sorteia novamente.
	if ($sorteado[2] == $sorteado[1]) {
		--$i;
	}
}
 
# Terceiro ganhador
for ($i = 1; $i < 2; $i++) {
	$sorteado[3] = $participantes[rand(0,$numParticipantes - 1)];
	// Caso o ganhador já tenha saido, sorteia novamente.
	if ($sorteado[3] == $sorteado[1] || $sorteado[3] == $sorteado[2]) {
		--$i;
	}
}
 
// Exibindo ganhadores
/*echo "<b>Ganhadores:</b> <br />";
echo "<b>1°</b> - " . $sorteado[1] . "<br />";
echo "<b>2°</b> - " . $sorteado[2] . "<br />";
echo "<b>3°</b> - " . $sorteado[3] . "<br />";
*/

# Primeiro ganhador
 
# Segundo ganhador

?>
    
</body>
</html>






