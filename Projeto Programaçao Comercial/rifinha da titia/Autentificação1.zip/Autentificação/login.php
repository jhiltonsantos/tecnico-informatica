<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="logincss.css">
        <link rel="stylesheet" type="text/javascript" href="jslogin.js">
        <link href="https://fonts.googleapis.com/css?family=Montserrat|Roboto+Condensed" rel="stylesheet">
        <style>
            body{
                height: 100%;
                background-color: transparent;
            }
            a{
                text-decoration: none;
                color:black;
            }
            body{
                font-family: 'Montserrat', sans-serif;
            }


        </style>
    </head>
    <body>
		<p>
			<?php
				if(isset($_GET["erro1"])){
					echo "<script>alert('Usuario ou senha invalidas');</script>";
				}
			?>
		</p>

           <div class="container">
        <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            <img id="profile-img" class="profile-img-card" src="//ssl.gstatic.com/accounts/ui/avatar_2x.png" />
            <p id="profile-name" class="profile-name-card"></p>
            


            <form class="form-signin" action="autenticasenha.php" method="post">
                
                <p>
                        <?php 
                            if(isset($_COOKIE["erro"])){
                                echo '<br>'.$_COOKIE["erro"].'<br>';        
                            }
                        ?>
                    </p>

                <span id="reauth-user" class="reauth-user"></span>
                <input type="text" name="user" id="inputUser" class="form-control" placeholder="Usuário " required autofocus>
                <input type="password" name="senha" id="inputPassword" class="form-control" placeholder="Senha" required>
				
                <div id="remember" class="checkbox">
                   
                </div><br>
                <input type="submit" value="entrar" id="entrar" name= "entrar"></br>

                <!--<button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Entrar</button><br>-->
            </form><!-- /form -->
           <a href="formulario.php">Cadastre-se</a>
        </div><!-- /card-container -->
    </div><!-- /container -->
    
        <?php
       
       
           ?>
      
    </body>
</html>

