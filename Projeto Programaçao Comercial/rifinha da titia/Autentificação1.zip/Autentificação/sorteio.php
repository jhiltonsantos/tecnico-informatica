<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
      
    
<?php

//Conexão BD
//$conexao = mysqli_connect("127.0.0.1","root","");

include_once 'conectbd.php';



/*
if(!$conexao){
  die("Erro de conexão: ".mysqli_error()."</br>");
}
else{
  echo "Conexão estabelecida com sucesso</br>";
}

/*$banco = mysqli_select_db( $conexao, "rifa");
if (!$banco) {
  die ("</br></br>Erro ao conectar em banco".mysqli_error()."</br>");
}
else{
  echo "</br></br>Conexão com banco realizada com sucesso</br>";
}




$ip = "127.0.0.2";
$data = "2018-02-17";
$hora = "00:37:30";
$id_nome = 07;
$id = 011;

$pas = "INSERT INTO sorteados (ip, data, hora, id_nome, id) VALUES ('$ip', '$data', '$hora', '$id_nome', '$id')";

$res = mysqli_query($pas);
if($res){
  echo ("</br>Inserção realizada com sucesso!!!");
}
else{
  echo ("</br> Erro:". mysqli_error());
}

//mysqli_close($conexao);





$host="localhost";
$port=3306;
$socket="";
$user="root";
$password="";
$dbname="banco2";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
  or die ('Could not connect to the database server' . mysqli_connect_error());

//$con->close();

$host="127.0.0.1";
$port=3306;
$socket="";
$user="root";
$password="";
$dbname="rifa";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
  or die ('Could not connect to the database server' . mysqli_connect_error());

//$con->close();

*/












class Sorteio{
    
      var $Sorteados;
      var $Sorteado;
      var $ip;
      private $Data;
      private $Hora;

  function __construct(){
                      $this->setar();
                      $this->BuscarSorteados();
                     }
                     
  function setar()
               {
                $this->ip=$_SERVER['REMOTE_ADDR'];
                $this->Data=date("Y-m-d");
                $this->Hora=date("H:i:s");
               }
               
  function Inserir($Codigo){
                          if (!empty($Codigo)){
                            if (is_numeric($Codigo)){
                              $sql=mysqli_query("insert into sorteados (ip, data, hora, id_nome, id) values('$this->ip', '$this->Data', '$this->Hora', '$Codigo', '$id')") or die(mysqli_error());
                              if ($sql){
                                return mysqli_insert_id();
                                }
                              }
                            }
                      }
                         
  

  function BuscarSorteados()
                         {
                          /* selecionando os sorteados pelo ip e pela data */
                         $sql=mysqli_query("select * from sorteados where ip='$this->ip' && data='$this->Data'") or die(mysqli_error());
                            if (mysqli_num_rows($sql)>0){
                               while($s=mysqli_fetch_object($sql))
                                   {
                                    $cods[]=$s->id_nome;
                                   }
                             }
                              else
                             {
                              $Sor='N';
                             }
                           /* selecionando todos os nomes disponiveis */
                          $sqlb=mysqli_query("select * from nomes") or die(mysqli_error());
                           $Numero=mysqli_num_rows($sqlb);
                           if (mysqli_num_rows($sqlb) >0)
                              {
                               while($sb=mysqli_fetch_object($sqlb))
                                    {
                                     $nomes[]=$sb->nome;
                                     $cod[]=$sb->id;
                                    }
                              }
                               else
                              {
                               echo "Não há nenhuma lista de nomes disponiveis no momento.";
                               exit;
                              }
                              
                           /* comparando os arrays de elementos */
                          if (is_array($cods))
                              {
                               $bsd=0;
                               foreach($cod as $key => $ids)
                                      {
                                       if (in_array($ids, $cods))
                                          {
                                           $bsd++;
                                          }
                                      }
                               if ($bsd == count($cod))
                                  {
                                   echo "Todos os nomes da lista já foram sorteados pelo seu ip $this->ip, na data atual $this->Data.";

                                  }
                              }
                           /* sorteando um numero */

                        do{
                              $N_sort=rand(0,$Numero);
                              $C_sort=$cod[$N_sort];
                              if ($Sor!='N')
                                 {
                                  if (in_array($C_sort, $cods))
                                     {
                                      $Tentativas[]=$N_sort;
                                      continue;
                                     }
                                      else
                                     {
                                      $Cso=$this->Inserir($C_sort);
                                      $Sorteio=$nomes[$N_sort]."(".$C_sort.")";
                                      echo "<br/>Codigo do sorteado $Cso.<br/>";
                                      break;
                                     }
                                 }
                                  else
                                 {
                                  $Cso=$this->Inserir($C_sort);
                                  $Sorteio=$nomes[$N_sort]."(".$C_sort.")";
                                  echo "<br/>Codigo do sorteado $Cso.<br/>";
                                  break;
                                 }
                             }
                              while(1>1);
                           echo "Tentativa número ".count($Tentativas).".<br/>";
                           echo $Sorteio;
                         } 




                         /* final da  função */
} /* final da classe */

/*$sorteio=new Sorteio;*/

?>

</body>
</html>