<?php
	$senha = $_POST["senha"];
	$user = $_POST["user"];
	
	if($user == "Tiago" && $senha == "123"){
		session_start();
		$_SESSION["usuario"] = $user;
		$_SESSION["autenticando"] = true;
		header("Location: pontos.php");
	}else{
		header("Location: login.php?erro1");
	}

?>