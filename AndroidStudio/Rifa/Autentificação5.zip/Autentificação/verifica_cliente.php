<!DOCTYPE html>

<html>
    <head>
        <link rel="shortcut icon" href="icone.ico" type="image/x-icon" />
        <meta charset="UTF-8">
        <title>Consulta Cliente</title>
        <link href="style.css" rel="stylesheet">
    </head>
    
    <style>
        #tabela{
            border-radius: 5px;
            background-color: white;
            padding: 20px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px #333;
        }

        th, td {
            text-align: left;
            padding: 8px;
        }
        
        th {
            background-color: white;
            color: black;
        }
        
        tr:nth-child(even){background-color: #f2f2f2}
        tr:hover {background-color: #c3c3c4}
    </style>
    
    <body>
        <div id="tabela"> 
        <?php
           //Conexão Banco de Dados
           require_once ('conectbd.php');

            $sql = mysqli_query($conecta_banco, "CALL Consulta_Cliente_Nome(@nome)");
           


            /*$procurar = mysqli_query($con, "SELECT * FROM usuario");
            
            echo "<table><tr>"
                    . "<th>Usuario</th>"
                    . "<th>Senha</th>"
                     . "<th>Nome Completo</th>"
                     . "<th>Data de Nascimento</th>"
                     . "<th>Sexo</th>"
                     . "<th>Telefone Whatsapp</th>"
                     . "<th>Telefone Opcional</th>"
                     . "<th>CPF</th>"
                     . "<th>E-mail</th>"
                     . "<th>Bairro</th>"
                     . "<th>Rua</th>"
                     . "<th>Completo</th>"
                     . "<th>CEP</th>"
                     . "<th>UF</th>"
                     . "<th>Nº da Casa</th>"
                     . "<th>Idade</th>"
                    . "</tr>";
            
            while($mostrar=mysqli_fetch_array($procurar)){
                echo    "<tr><td>" . $mostrar['usuario'] 
                        . "</td><td>" . $mostrar['senha']
                        . "</td><td>" . $mostrar['nome_completo'] 
                        . "</td><td>" . $mostrar['telefone_wpp'] 
                        . "</td><td>" . $mostrar['email'] 
                        . "</td><td>" . $mostrar['CPF'] 
                        . "</td><td>" . $mostrar['Rua'] 
                        . "</td><td>" . $mostrar['Numero'] 
                        . "</td><td>" . $mostrar['Completo'] 
                        . "</td><td>" . $mostrar['Bairro'] 
                        . "</td><td>" . $mostrar['CEP'] 
                        . "</td><td>" . $mostrar['Cidade']
                        . "</td><td>" . $mostrar['UF']
                        . "</td><td>" . $mostrar['data_nascimento']
                        . "</td><td>" . $mostrar['sexo']    
                        . "</td></tr>";

            }
            
            echo "</table>"; */

           // $con-> close();
            
        ?>
        </div>
    </body>
</html>