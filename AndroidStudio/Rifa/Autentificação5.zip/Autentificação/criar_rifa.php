<html>
    <head>
        <meta charset="UTF-8">
        <title>Recebe Formulario Rifa</title>
    <script type="text/javascript" src="jquery-3.3.1.js"></script>
    </head>
    <body>
	
        <?php
            //Conexão BD
            require_once ('conectbd.php');
            
            //Recebendo Formulário
            $nome = $_POST['nome_rifa'];
            $descricao = $_POST['descricao'];
            $premio  = $_POST['premio'];
            $dt_inicio = $_POST['data_inicio'];
            $dt_prev = $_POST['data_prev'];
      	
            
            $inserir = "INSERT INTO Rifa('nome_rifa','descrição','Premio','data_inicio','data_prev_sorteio') VALUES ('$nome','$descricao','$premio','$dt_inicio','$dt_prev')";
                
            $resf = mysqli_query($conecta_banco, $inserir);
                
            if($resf){
                    $pass = 'Rifa Cadastrado!';
                    echo $pass;
                    //header("location: AdmMain.html");
            }
            else {
                    $pass = 'Erro ao Inserir!';
                    echo $pass;
                    //header("location: form_rifa.php");
            }
            
            




        ?>

    </body>
</html>