<?php
    
     require_once ('conectbd.php');

    $nome = filter_input(INPUT_POST, "nome_completo");
    
    $res = mysqli_query($con, "SELECT * FROM usuario WHERE nome_completo = '$nome'");
    
    if($res){
        $deu_certo = 'Cliente Selecionado!';
        setcookie("corValido", "green", time() + 1, "/");
        setcookie("valido", $deu_certo, time() + 1, "/");
       // header("location: seleciona_cliente.html");
    }
    else {
        $deu_certo = 'Erro ao selecionar!';
        $erro = 1;
        setcookie("corValido", "red", time() + 1, "/");
        setcookie("valido", $deu_certo, time() + 1, "/");
        header("location: seleciona_cliente.html");
    }


?>