<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
      
    
<?php

include_once 'conectbd.php';

class Sorteio{
    
      var $Sorteados;
      var $Sorteado;
      var $cod_sorteio;
      private $dt_compra;
      private $hr_compra;

  function __construct(){
                      $this->setar();
                      $this->BuscarSorteados();
                     }
                     
  function setar()
               {
                $this->cod_sorteio=$_SERVER['REMOTE_ADDR'];
                $this->dt_compra=date("Y-m-d");
                $this->hr_compra=date("H:i:s");
               }
               
  function Inserir($Codigo){
                          if (!empty($Codigo)){
                           
                            if (is_numeric($Codigo)){
                                $sql=mysqli_query("INSERT INTO Sorteio (cod_sorteio, hora_compra, data_compra) values('$this->cod_sorteio', '$this->dt_compra', '$this->hr_compra')") or die(mysqli_error());
                                
                                if ($sql){
                                   return mysqli_insert_id();
                                }
                              
                              }
                            
                            }
                      }
                         
  

  function BuscarSorteados()
                         {
                          /* selecionando os sorteados pelo ip e pela data */
                         $sql = mysqli_query("SELECT * FROM Sorteio WHERE cod_sorteio='$this->cod_sorteio' && dt_compra='$this->dt_compra'") 
                         $sql .= or die(mysqli_error());
                            if (mysqli_num_rows($sql)>0){
                               while($s=mysqli_fetch_object($sql))
                                   {
                                    $cods[]=$s->id_nome;
                                   }
                             }
                              else
                             {
                              $Sor='N';
                             }
                           
                           /* selecionando todos os nomes disponiveis */
                          $sqlb=mysqli_query("SELECT * FROM Usuario where tipo = 2 AND SELECT * FROM Pontos WHERE Status = 'Indisponivel'") or die(mysqli_error());
                           $Numero=mysqli_num_rows($sqlb);
                           if (mysqli_num_rows($sqlb) >0)
                              {
                               while($sb=mysqli_fetch_object($sqlb))
                                    {
                                     $nomes[]=$sb->nome;
                                     $cod[]=$sb->id;
                                    }
                              }
                               else
                              {
                               echo "Não há nenhuma lista de nomes disponiveis no momento.";
                               exit;
                              }
                              
                           /* comparando os arrays de elementos */
                          if (is_array($cods))
                              {
                               $bsd=0;
                               foreach($cod as $key => $ids)
                                      {
                                       if (in_array($ids, $cods))
                                          {
                                           $bsd++;
                                          }
                                      }
                               if ($bsd == count($cod))
                                  {
                                   echo "Todos os nomes da lista já foram sorteados pelo seu ip $this->ip, na data atual $this->Data.";

                                  }
                              }
                           /* sorteando um numero */

                        do{
                              $N_sort=rand(0,$Numero);
                              $C_sort=$cod[$N_sort];
                              if ($Sor!='N')
                                 {
                                  if (in_array($C_sort, $cods))
                                     {
                                      $Tentativas[]=$N_sort;
                                      continue;
                                     }
                                      else
                                     {
                                      $Cso=$this->Inserir($C_sort);
                                      $Sorteio=$nomes[$N_sort]."(".$C_sort.")";
                                      echo "<br/>Codigo do sorteado $Cso.<br/>";
                                      break;
                                     }
                                 }
                                  else
                                 {
                                  $Cso=$this->Inserir($C_sort);
                                  $Sorteio=$nomes[$N_sort]."(".$C_sort.")";
                                  echo "<br/>Codigo do sorteado $Cso.<br/>";
                                  break;
                                 }
                             }
                              while(1>1);
                           echo "Tentativa número ".count($Tentativas).".<br/>";
                           echo $Sorteio;
                         } 




                         /* final da  função */
} /* final da classe */

/*$sorteio=new Sorteio;*/

?>

</body>
</html>