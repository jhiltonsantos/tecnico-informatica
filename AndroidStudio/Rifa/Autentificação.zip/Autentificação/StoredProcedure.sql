use rifa;

-- Confirma o pagamento, alterando os status das tabelas Pontos e Sorteio
Delimiter //
Create Procedure confirma_pagamento(numero_pr int, data_Paga date, hora_paga time) 
Begin 
Update Sorteio set Status = 'Pagamento Concluído' where numero = numero_pr;
Update Sorteio set data_pagamento = data_paga where numero = numero_pr;
Update Sorteio set hora_pagamento = hora_paga where numero = numero_pr;
Update Pontos set Status = 'Indisponível' where numero = numero_pr;

End//
Delimiter ;
call confirma_pagamento (6, '2018/02/03', '11:19');



-- Torna a pessoa Administradora 
DELIMITER //
Create Procedure Torna_ADM (nome varchar(30))
Begin
	Update Usuario SET tipo='ADM' where usuario = nome; 
End//
DELIMITER ;
call Torna_ADM ('Felipi-');


-- Torna um ADM em Cliente
DELIMITER //
Create Procedure Torna_Cliente (nome varchar(30))
Begin
	Update Usuario SET tipo='Cliente' where usuario = nome; 
End//
DELIMITER ;
call Torna_Cliente ('Felipi-');

-- Pontos de Sorteio de acordo com o nome digitado
Delimiter //
Create Procedure Consulta_Cliente_Nome (nome varchar(30))
BEGIN
	select * from Sorteio where usuario in (select usuario from Usuario where nome_completo like concat('%',nome,'%'));
END//
Delimiter ;

call Consulta_Cliente_Nome ('Fel');




